package com.example.sijilalqadaya;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL = "court_sessions";
    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "تنبيهات الجلسات", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تذكير بمواعيد الجلسات قبلها بيوم");
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    @Override public void onReceive(Context context, Intent intent) {
        createChannel(context);
        String title = intent.getStringExtra("title");
        String date = intent.getStringExtra("date");
        Intent open = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        PendingIntent pi = PendingIntent.getActivity(context, 9001, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تذكير بموعد جلسة غداً")
            .setContentText((title == null ? "لديك جلسة" : title) + " — " + (date == null ? "" : date))
            .setStyle(new Notification.BigTextStyle().bigText("تذكير: لديك جلسة غداً بتاريخ " + (date == null ? "" : date) + " في القضية: " + (title == null ? "" : title)))
            .setAutoCancel(true).setContentIntent(pi);
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
