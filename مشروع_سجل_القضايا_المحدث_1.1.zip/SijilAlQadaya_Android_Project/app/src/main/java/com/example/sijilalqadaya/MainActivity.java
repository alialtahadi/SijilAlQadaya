package com.example.sijilalqadaya;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.print.PrintManager;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int CREATE_CSV = 4102;
    private static final int NOTIFICATION_PERMISSION = 4103;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ReminderReceiver.createChannel(this);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
    }

    public class Bridge {
        @JavascriptInterface public void saveCsv(String csv) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/csv");
                intent.putExtra(Intent.EXTRA_TITLE, "سجل_القضايا.csv");
                pendingCsv = csv;
                startActivityForResult(intent, CREATE_CSV);
            });
        }
        @JavascriptInterface public void exportPdf() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("سجل القضايا");
                pm.print("سجل القضايا", adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
            });
        }
        @JavascriptInterface public void scheduleReminder(String id, String date, String title) {
            runOnUiThread(() -> schedule(id, date, title));
        }
        @JavascriptInterface public void cancelReminder(String id) {
            runOnUiThread(() -> cancel(id));
        }
    }

    private void schedule(String id, String date, String title) {
        try {
            Calendar when = Calendar.getInstance();
            when.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date));
            when.add(Calendar.DAY_OF_YEAR, -1);
            when.set(Calendar.HOUR_OF_DAY, 16); when.set(Calendar.MINUTE, 0);
            when.set(Calendar.SECOND, 0); when.set(Calendar.MILLISECOND, 0);
            if (when.getTimeInMillis() <= System.currentTimeMillis()) return;
            Intent i = new Intent(this, ReminderReceiver.class);
            i.putExtra("title", title); i.putExtra("date", date);
            int request = id.hashCode() & 0x7fffffff;
            PendingIntent pi = PendingIntent.getBroadcast(this, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }
    private void cancel(String id) {
        Intent i = new Intent(this, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(this, id.hashCode() & 0x7fffffff, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi); pi.cancel(); }
    }
    private String pendingCsv = "";
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_CSV && resultCode == RESULT_OK && data != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) out.write(("\uFEFF" + pendingCsv).getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) {}
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
